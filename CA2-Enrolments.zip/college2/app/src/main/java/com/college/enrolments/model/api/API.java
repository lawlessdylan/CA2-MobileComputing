package com.college.enrolments.model.api;

import com.college.enrolments.model.Enrolment;

public interface API {  //Interface

    //These methods send a request to the server. A method is then invoked on a listener object passed as a parameter when a response is returned.

    void login(String email, String password, APIListener listener); //class that implements Interface has login

    void loadEnrolments(APIListener listener);
    void deleteEnrolment(Enrolment enrolment, APIListener listener);
    void storeEnrolment(Enrolment enrolment, APIListener listener);
    void updateEnrolment(Enrolment enrolment, APIListener listener);

    void loadCourses(APIListener listener);
    void loadStudents(APIListener listener);
}
