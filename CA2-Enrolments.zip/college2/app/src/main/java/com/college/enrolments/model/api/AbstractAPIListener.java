package com.college.enrolments.model.api;

import com.college.enrolments.model.Course;
import com.college.enrolments.model.Enrolment;
import com.college.enrolments.model.Student;
import com.college.enrolments.model.User;

import java.util.List;

public abstract class AbstractAPIListener implements APIListener {//implements the methods within the APIListener

    @Override
    public void onLogin(User user) {  } //this method does not do anything, overridden in a subclass

    @Override
    public void onEnrolmentsLoaded(List<Enrolment> enrolments) { }

    @Override
    public void onCoursesLoaded(List<Course> courses) { }

    @Override
    public void onStudentsLoaded(List<Student> students) { }

    @Override
    public void onEnrolmentStored(Enrolment storedEnrolment) { }

    @Override
    public void onEnrolmentUpdated(Enrolment updatedEnrolment) { }

    @Override
    public void onEnrolmentDeleted(Enrolment deletedEnrolment) { }

}
