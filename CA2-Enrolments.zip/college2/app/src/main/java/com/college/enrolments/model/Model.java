package com.college.enrolments.model;

import android.app.Application;

import com.college.enrolments.model.api.APIListener;
import com.college.enrolments.model.api.AbstractAPIListener;
import com.college.enrolments.model.api.WebApi;
import com.college.enrolments.model.api.API;

import java.util.ArrayList;
import java.util.List;


public class Model {

    private static Model sInstance = null;

    private final API mApi;
    private User mUser; //to find who is currently logged in
    private List<Enrolment> mEnrolments;
    private List<Course> mCourses;
    private List<Student> mStudents;


    public static Model getInstance(Application application) {
        if (sInstance == null){
            sInstance = new Model(application); //references application object.
        }
        return sInstance;
    }//makes sure there is only one instance of the model class

    private final Application mApplication;

    private Model(Application application) {
        mApplication = application;
        mApi = new WebApi(mApplication, this); //initialising in constructor as used throughout model
        mEnrolments = new ArrayList<>(); //creates empty arraylist of enrolments
        mCourses = new ArrayList<>();
        mStudents = new ArrayList<>();

    }

    public Application getApplication() {
        return mApplication;
    }

    public void login(String email, String password,  APIListener listener) { //login method takes email and password as parameters
        mApi.login(email, password, listener); //calls login method in API class
    }

    public User getUser() { //gets user and returns it
        return mUser;
    }

    public void setUser(User user) { //sets user
        this.mUser = user;
    }

    public List<Enrolment> getEnrolments() {
        return mEnrolments;
    } //returns a list of all enrolments

    public void storeEnrolment(Enrolment enrolment){ //stores the enrolment on the list of enrolments
        mEnrolments.add(enrolment);
    }

    public void loadEnrolments(AbstractAPIListener listener) {
        mApi.loadEnrolments(listener); //load enrolments and notify listener object
    }

    public void addCourses(List<Course> courses){ //gets list of courses
        mCourses.clear(); //clears out the list of courses
        mCourses.addAll(courses); //adds the students to courses
    }

    public Course findCourseById(int courseId){
        Course course = null; //returns null if not found

        for (Course c: mCourses){ //loops through list of courses and find the matching ID
            if (c.getId() == courseId) {
                course = c;
                break;
            }
        }
        return course; //returns the course
    }

    public List<Course> getCourses() { return mCourses; } //returns a list of all courses

    public void loadCourses(AbstractAPIListener listener) { mApi.loadCourses(listener); }
    //refers to listener and defers the method to the API class

    public List<Student> getStudents() { return mStudents; } //returns a list of all students

    public Student findStudentById(int studentId){
        Student student = null; //returns null if not found
        for (Student s : mStudents){ //loops through list of students and find the matching ID
            if (s.getId() == studentId) {
                student = s;
                break;
            }
        }
        return student; //returns the student
    }

    public void loadStudents(AbstractAPIListener listener){ mApi.loadStudents(listener); }  //refers to listener and delegates the method to the API class

    public void addStudents(List<Student> students){ //gets list of students
        mStudents.clear(); //clears out the list of students
        mStudents.addAll(students); //adds the students to students
    }

    public void deleteEnrolment(Enrolment deletedEnrolment){ //removes from list of enrolments
        mEnrolments.remove(deletedEnrolment);
    }

    public void deleteEnrolment(Enrolment enrolment, AbstractAPIListener apiListener){ //refers to listener and delegates the method to the API class
        mApi.deleteEnrolment(enrolment, apiListener);
    }

    public Enrolment findEnrolmentById(int enrolmentId) { //takes enrolment id
        Enrolment enrolment = null; //enrolment initialised to null

        for (Enrolment e : mEnrolments){ //looping through list of enrolments
            if (e.getId() ==  enrolmentId){ //checking if id = enrolment id,
                enrolment = e; //setting variable to enrolment
                break; //break out of loop
            }
        }
        return enrolment; //returns enrolment

    }

    public void storeEnrolment(Enrolment enrolment, APIListener listener){ //refers to listener and delegates the method to the API class
        mApi.storeEnrolment(enrolment, listener);
    }

    public void updateEnrolment(Enrolment enrolment, APIListener listener) { //refers to listener and delegates the method to the API class
        mApi.updateEnrolment(enrolment, listener);
    }





}
