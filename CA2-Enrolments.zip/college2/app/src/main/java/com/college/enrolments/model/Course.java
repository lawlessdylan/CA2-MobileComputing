package com.college.enrolments.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Course {


    public static Course getCourse(JSONObject jsonObject) throws JSONException { //gets course properties from jsonObject and creates Course object
        int id = jsonObject.getInt("id");
        String title = jsonObject.getString("title");
        String code = jsonObject.getString("code");
        String description = jsonObject.getString("description");
        int points = jsonObject.getInt("points");
        int level = jsonObject.getInt("level");
        Course course = new Course(id, title, code, description, points, level);

        return course; //returns course object
    }

        public static List<Course> getCourses(JSONArray jsonArray) throws JSONException{ //gets arrayList of courses and returns array of courses
            List<Course> courses = new ArrayList<>();
            for (int i = 0; i != jsonArray.length(); i++){ //loop through json array
                JSONObject jsonObject = jsonArray.getJSONObject(i); //retrieve each object out of it
                Course course = Course.getCourse(jsonObject); //pass jsonObject to course.getCourse
                courses.add(course);
            }
            return courses; //returns list of courses
        }


        private int id;
        private String title;
        private String code;
        private String description;
        private int points;
        private int level;

        public Course(int id, String title, String code, String description, int points, int level){
            this.id = id;
            this.title = title;
            this.code = code;
            this.description = description;
            this.points = points;
            this.level = level;


    }

    //Gets and sets for Course

    public int getId() {
        return id;
    }
    public void setId(int id){
            this.id = id;
    }
    public String getTitle(){
            return title;
    }
    public void setTitle(String title){
            this.title = title;
    }
    public String getCode(){
            return code;
    }
    public void setCode(String code){
            this.code = code;
    }
    public String getDescription(){
            return description;
    }
    public void setDescription(String description){
            this.description = description;
    }
    public int getPoints(){
            return points;
    }
    public void setPoints(int points){
            this.points = points;
    }
    public int getLevel(){
            return level;
    }
    public void setLevel(int level){
            this.level=level;
    }

}

