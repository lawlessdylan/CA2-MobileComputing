package com.college.enrolments.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Enrolment implements Comparable<Enrolment> {

    public static final String REGISTERED = "registered"; //constant defined for registered
    public static final String ATTENDING = "attending"; //constant defined for attending
    public static final String DEFERRED = "deferred"; //constant defined for deferred
    public static final String WITHDRAWN = "withdrawn"; //constant defined for withdrawn

    public static Enrolment getEnrolment(JSONObject jsonObject) throws JSONException {
        int id = jsonObject.getInt("id");
        String date = jsonObject.getString("date");
        String time = jsonObject.getString("time");
        int courseId = jsonObject.getInt("course_id");
        int studentId = jsonObject.getInt("student_id");
        String status = jsonObject.getString("status");
        Enrolment enrolment = new Enrolment(id, date, time, courseId, studentId, status);
        
        return enrolment;

    }

    public static List<Enrolment> getEnrolments(JSONArray jsonArray) throws JSONException{ //takes reference to jsonArray and returns list of enrolments
        List<Enrolment> enrolments = new ArrayList<>();
        for (int i = 0; i != jsonArray.length(); i++){ //loop through json array
            JSONObject jsonObject = jsonArray.getJSONObject(i); //retrieve each object out of it

            Enrolment enrolment = Enrolment.getEnrolment(jsonObject); //pass jsonObject to enrolment.getEnrolment
            Course course = Course.getCourse(jsonObject.getJSONObject("course")); //gets course associated with enrolment
            Student student = Student.getStudent(jsonObject.getJSONObject("student")); //gets student associated with enrolment

            enrolment.setCourse(course); //sets the course
            enrolment.setStudent(student); //sets the student

            enrolments.add(enrolment); //adds the enrolment to the enrolment object
        }
        return enrolments;
    }

    private int id;
    private String date;
    private String time;
    private int courseId;
    private int studentId;
    private String status;
    private Course course;
    private Student student;


    public Enrolment(int id, String date, String time, int courseId, int studentId, String status){
        this.id = id;
        this.date = date;
        this.time = time;
        this.courseId = courseId;
        this.studentId = studentId;
        this.status = status;
    }

    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }

    public String getDate(){
        return date;
    }
    public void setDate(String date){
        this.date = date;
    }

    public String getTime(){
        return time;
    }
    public void setTime(String time){
        this.time = time;
    }

    public String getStatus(){
        return status;
    }
    public void setStatus(String status){
        this.status = status;
    }

    public int getCourseId(){ return courseId; }
    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public int getStudentId() {
        return studentId;
    }
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public Course getCourse(){
        return course;
    }
    public void setCourse(Course course) {
        this.course = course;
    }

    public Student getStudent() {
        return student;
    }
    public void setStudent(Student student){
        this.student = student;
    }

    @Override
    public int compareTo(Enrolment o) {
        return 0;
    }
}
