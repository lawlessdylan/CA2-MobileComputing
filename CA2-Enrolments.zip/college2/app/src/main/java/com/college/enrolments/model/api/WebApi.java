package com.college.enrolments.model.api;

import android.app.Application;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.college.enrolments.model.Course;
import com.college.enrolments.model.Enrolment;
import com.college.enrolments.model.Model;
import com.college.enrolments.model.Student;
import com.college.enrolments.model.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WebApi implements API {    //implements API interface

    public static final String BASE_URL = "http://10.0.2.2:8000/"; //base url of REST API

    private final Application mApplication;
    private Model mModel;

    private RequestQueue mRequestQueue; //creates request queue

    public WebApi(Application application, Model model) {
        mApplication = application; //stores application object
        mRequestQueue = Volley.newRequestQueue(application);
        mModel = model; //declared as we use model object throughout
    }

    public void login(String email, String password, final APIListener listener){
        String url = BASE_URL + "api/login"; //base url + url to login to REST API
        JSONObject jsonObject = new JSONObject(); //

        try { //try and catch as jsonObject is able to generate json exception
            jsonObject.put("email", email); //properties within jsonObject sent to REST API
            jsonObject.put("password", password);


            Response.Listener<JSONObject> successListener = new Response.Listener<JSONObject>() { //creating instance of response listener class
                @Override
                public void onResponse(JSONObject response){ //creating subclass

                    try {
                        User user = User.getUser(response); //successful response will respond with a User object
                        listener.onLogin(user);

                    }
                    catch (JSONException ex) {
                        Toast.makeText(mApplication, "JSON exception", Toast.LENGTH_LONG).show(); //toast if json request fails

                    }
                }

            };

            Response.ErrorListener errorListener = new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error){
                   Toast.makeText(mApplication, "Error Response", Toast.LENGTH_LONG).show();
                }
            };

            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsonObject, successListener, errorListener); //sends json object request to REST API.
            mRequestQueue.add(request); //adds request to request queue
        }
        catch (JSONException e) { //if json fails toast will show
            Toast.makeText(mApplication, "JSON exception", Toast.LENGTH_LONG).show();

        }

    }

    @Override
    public void loadEnrolments(final APIListener listener) {

        String url = BASE_URL + "api/enrolments"; //url to GET enrolments from REST API

        Response.Listener<JSONArray> successListener = new Response.Listener<JSONArray>() { //successful response
            @Override
            public void onResponse(JSONArray response){

                try {
                    List<Enrolment> enrolments = Enrolment.getEnrolments(response); //array of enrolment objects
                    if (listener != null) { //if a listener needs a response
                        listener.onEnrolmentsLoaded(enrolments); //call onEnrolmentsLoaded method, passing enrolments as parameter
                    }
                }
                catch (JSONException ex) {
                    Toast.makeText(mApplication, "JSON exception", Toast.LENGTH_LONG).show(); //return error message if unsuccessful

                }
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(mApplication, "Volley error" + error.getMessage(), Toast.LENGTH_LONG).show(); //if REST API returns error then show message "Volley error"

            }
        };

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, successListener, errorListener){
            //create request object, sending get request, body of request is null, passes success and error listener
            @Override
            public Map<String, String> getHeaders() { //subclass of jsonArrayRequest
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Accept", "application/json");
                headers.put("Authorization", "Bearer " + mModel.getUser().getToken()); //sends users token for authentication
                return headers; //returns the headers
            }
        };
        mRequestQueue.add(request); //add request object to request queue
    }

    @Override
    public void loadCourses(final APIListener listener) {
        final User user = mModel.getUser(); //reference to user object
        if (user == null) { //if null call listener.onEnrolmentStored and pass null, no user logged in
            listener.onCoursesLoaded(null);
        }
        else {

            String url = BASE_URL + "api/courses"; //url to GET courses from REST API

            Response.Listener<JSONArray> responseListener = new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray jsonArray) {
                    try {
                        List<Course> courses = Course.getCourses(jsonArray); //array list of course objects
                        listener.onCoursesLoaded(courses); //call onCoursesLoaded method, passing courses as parameter

                    } catch (JSONException ex) {
                        listener.onCoursesLoaded(null); //if failed then pass null to coursesLoaded method
                    }
                }
            };

            Response.ErrorListener errorListener = new Response.ErrorListener() { //new errorListener object
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(mApplication, "Volley error" + error.getMessage(), Toast.LENGTH_LONG).show(); //if REST API returns error then show message "Volley error"

                }
            };


            JsonArrayRequest request = new JsonArrayRequest(
                    Request.Method.GET, url, null, responseListener, errorListener){
                //create request object, sending get request, body of request is null, passes response and error listener
                @Override
                public Map<String, String> getHeaders(){ //subclass of jsonArrayRequest
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Authorization", "Bearer " + user.getToken()); //sends users token for authentication
                    return headers; //returns headers
                }
            };

            mRequestQueue.add(request);
        }
    }

    @Override
    public void loadStudents(final APIListener listener) {
        final User user = mModel.getUser(); //reference to user object
        if (user == null) { //if null call listener.onEnrolmentStored and pass null, no user
            listener.onStudentsLoaded(null);
        }
        else {

            String url = BASE_URL + "api/students"; //url for http request to REST API for students

            Response.Listener<JSONArray> responseListener = new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray jsonArray) {
                    try {
                        List<Student> students = Student.getStudents(jsonArray);
                        listener.onStudentsLoaded(students);

                    } catch (JSONException e) {
                        listener.onStudentsLoaded(null);
                    }
                }
            };

            Response.ErrorListener errorListener = new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(mApplication, "Volley error" + error.getMessage(), Toast.LENGTH_LONG).show();

                }
            };


            JsonArrayRequest request = new JsonArrayRequest(
                    Request.Method.GET, url, null, responseListener, errorListener){
                @Override
                public Map<String, String> getHeaders(){
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Authorization", "Bearer " + user.getToken());
                    return headers;
                }
            };

            mRequestQueue.add(request);
        }
    }

    @Override
    public void deleteEnrolment(final Enrolment enrolment, final APIListener listener) {
        final User user = mModel.getUser(); //reference to user object
        if (user == null) { //if null call listener.onEnrolmentStored and pass null, no user logged in
            listener.onEnrolmentDeleted(null);
        }
        else {

                String url = BASE_URL + "api/enrolments/" + enrolment.getId(); //url for http request to REST API + the ID of the enrolment object to be deleted

                Response.Listener<JSONObject> responseListener = new Response.Listener<JSONObject>() { //response listener implements on response method
                    @Override
                    public void onResponse(JSONObject jsonObject) { //takes in jsonObject

                        listener.onEnrolmentDeleted(enrolment); // calls listener method passing Enrolment object to be deleted
                    }
                };

                Response.ErrorListener errorListener = new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) { //if there is a volley error the onEnrolmentDeleted method is called with the parameter of null
                        listener.onEnrolmentDeleted(null);
                    }
                };

                JsonObjectRequest request = new JsonObjectRequest( //new Request object is an instance of JsonObjectRequest
                        Request.Method.DELETE, url, null, responseListener, errorListener){ //DELETE request to be sent to REST API
                    @Override
                    public Map<String, String> getHeaders(){ //subclass, headers for the json request
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Authorization", "Bearer " + user.getToken()); //user token retrieved from user object for authorization
                        return headers; //return headers
                    }
                };

                mRequestQueue.add(request);
            }
        }

    @Override
    public void storeEnrolment(Enrolment enrolment, final APIListener listener) {
        final User user = mModel.getUser(); //reference to user object
        if (user == null) { //if null call listener.onEnrolmentStored and pass null, no user
            listener.onEnrolmentStored(null);
        }
        else {
            try{
                String url = BASE_URL + "api/enrolments"; //url for http request to REST API


                JSONObject requestBody = new JSONObject(); //creating json object
                //putting details of enrolment to be stored in json object
                requestBody.put("date", enrolment.getDate());
                requestBody.put("time", enrolment.getTime());
                requestBody.put("status", enrolment.getStatus());
                requestBody.put("course_id", enrolment.getCourseId());
                requestBody.put("student_id", enrolment.getStudentId());

                Response.Listener<JSONObject> responseListener = new Response.Listener<JSONObject>() { //response listener implements on response method
                    @Override
                    public void onResponse(JSONObject jsonObject) { //takes in jsonObject
                        try{
                            Enrolment storedEnrolment = Enrolment.getEnrolment(jsonObject); //converts storedEnrolment object into jsonObject
                            listener.onEnrolmentStored(storedEnrolment); // calls listener method passing storedEnrolment object
                        } catch (JSONException ex) {
                            listener.onEnrolmentStored(null); //calls onEnrolmentStored method and passes null if exception
                        }
                    }
                };

                Response.ErrorListener errorListener = new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) { //if there is a volley error the onEnrolmentStored method is called with the parameter of null
                        listener.onEnrolmentStored(null); //
                    }
                };

                JsonObjectRequest request = new JsonObjectRequest( //new Request object is an instance of JsonObjectRequest
                        Request.Method.POST, url, requestBody, responseListener, errorListener){ //POST request
                    @Override
                    public Map<String, String> getHeaders(){ //subclass, headers for the json request
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Authorization", "Bearer " + user.getToken()); //user token retrieved from user object for authorization
                        return headers; //return headers
                    }
                };

                mRequestQueue.add(request); //
            }
            catch (JSONException ex){
                listener.onLogin(null);
            }
        }
    } //

    @Override
    public void updateEnrolment(Enrolment enrolment, final APIListener listener) {
        final User user = mModel.getUser(); //reference to user object
        if (user == null) { //if null call listener.onEnrolmentStored and pass null, no user logged in
            listener.onEnrolmentUpdated(null);
        }
        else {
            try{
                String url = BASE_URL + "api/enrolments/" + enrolment.getId(); //url for http request to REST API + the ID of the enrolment object to be updated

                //creates jsonObject with the new values
                JSONObject requestBody = new JSONObject();
                requestBody.put("date", enrolment.getDate());
                requestBody.put("time", enrolment.getTime());
                requestBody.put("status", enrolment.getStatus());
                requestBody.put("course_id", enrolment.getCourseId());
                requestBody.put("student_id", enrolment.getStudentId());



                Response.Listener<JSONObject> responseListener = new Response.Listener<JSONObject>() { //response listener implements on response method
                    @Override
                    public void onResponse(JSONObject jsonObject) { //takes in jsonObject
                        try{
                            Enrolment updatedEnrolment = Enrolment.getEnrolment(jsonObject);
                            listener.onEnrolmentUpdated(updatedEnrolment); // calls listener method passing Enrolment object to be updated
                        } catch (JSONException ex) {
                            listener.onEnrolmentUpdated(null); //if fails then pass the updated enrolment with null
                        }
                    }
                };

                Response.ErrorListener errorListener = new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) { //if there is a volley error the onEnrolmentUpdated method is called with the parameter of null
                        listener.onEnrolmentUpdated(null);
                    }
                };

                JsonObjectRequest request = new JsonObjectRequest( //new Request object is an instance of JsonObjectRequest
                        Request.Method.PUT, url, requestBody, responseListener, errorListener){ //PUT request to be sent to REST API
                    @Override
                    public Map<String, String> getHeaders(){ //subclass, headers for the json request
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Content-Type", "application/json");
                        headers.put("Accept", "application/json");
                        headers.put("Authorization", "Bearer " + user.getToken()); //user token retrieved from user object for authorization
                        return headers; //returns headers
                    }
                };

                mRequestQueue.add(request);
            }
            catch (JSONException ex){
                listener.onLogin(null);
            }
        }

    }

}
