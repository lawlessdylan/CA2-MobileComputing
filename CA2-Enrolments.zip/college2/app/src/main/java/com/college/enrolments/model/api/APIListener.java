package com.college.enrolments.model.api;

import com.college.enrolments.model.Course;
import com.college.enrolments.model.Enrolment;
import com.college.enrolments.model.Student;
import com.college.enrolments.model.User;

import java.util.List;

public interface APIListener {

    //Methods for when the requests have completed. Listener objects implement APIListener

    void onLogin(User user);

    void onEnrolmentsLoaded(List<Enrolment> enrolments);
    void onEnrolmentStored(Enrolment storedEnrolment);
    void onEnrolmentUpdated(Enrolment updatedEnrolment);
    void onEnrolmentDeleted(Enrolment deletedEnrolment);

    void onCoursesLoaded(List<Course> courses);
    void onStudentsLoaded(List<Student> students);

}
